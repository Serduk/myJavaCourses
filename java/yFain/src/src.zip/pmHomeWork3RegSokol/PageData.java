package pmHomeWork3RegSokol;

/**
 * Created by serega on 21/11/15.
 */
public class PageData {
    String pEmail = ".//*[@class='ns-f-text ns-f-text-email']";
    String pPass = ".//*[@class='ns-f-text ns-f-text-pass']";
    String pButtonNext = ".//*[@class='ibutton-red ibutton-large']";

    String pName = ".//*[@name='first_name']";
    String pSurname = ".//*[@name='last_name']";
    String pPhoneNumber = ".//*[@class='text phone']";
    String pDateBirth = ".//*[@class='ns-f-text ns-f-day']";
    String pYearBirth = ".//*[@class='ns-f-text ns-f-year']";
    String pMonth = ".//*[@class='ns-f-text ns-f-month']";
    String pRegButton = ".//*[@type='submit']";

//    <button class="ibutton-red ibutton-large" type="submit">Зарегистрироваться</button>

}
