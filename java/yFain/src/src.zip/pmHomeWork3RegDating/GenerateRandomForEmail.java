package pmHomeWork3RegDating;

/**
 * Created by serega on 21/11/15.
 */
public class GenerateRandomForEmail {
   int random = (int) (Math.random() * 999999999);

    public int getRandom(){
        return random;
    }

}
